# vector
A resizable array in C similar to std::vector from the C++ STL.
