#include <stdio.h>
#include <stdlib.h>

int filecopy(char* input_name,char* output_name)
{
    FILE *input, *output;
     unsigned char current_byte;

    input = fopen(input_name, "rb");
    output = fopen(output_name, "wb");
    if(input==NULL || output==NULL)
    {
        return -1;
    }
    
    while(1)
    {
        fread(&current_byte, sizeof(unsigned char), 1, input);
        if(feof(input))
        {
            break;
        }
        fwrite(&current_byte, sizeof(unsigned char), 1, output);
    }
    fflush(input);
    fflush(output);
    fclose(input);
    fclose(output);
    return 0;
}

//https://github.com/atamenne/file-copy/blob/master/filecopy.c
//Simple program to copy a file
int main(int argc,char* argv[])
{
    char input_name[30], output_name[30];
    if(argc>1)
    {
        strcpy(input_name,argv[1]);
    }else{
        printf("enter input_name:");
        scanf("%s", &input_name);  
    }
    if(argc>2)
    {
        strcpy(output_name,argv[2]);
    }else{
       
        printf("Enter output_name:");
        scanf("%s", &output_name);
    }
     printf("argc=%d input_name=%s output_name=%s\n",argc,input_name,output_name);
     
    filecopy(input_name,output_name); 
    return 0;
}