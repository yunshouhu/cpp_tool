#include "copy.h"

int test_copy(const char *from, const char *to);
int test_copy_dir(const char *from, const char *to);
int test_copy_file(const char *from, const char *to);
void run_test();

int test_copy(const char *from, const char *to)
{
  printf("Testing copy()\n");
  copy(from, to);
  printf("Done!\n\n");
  return 0;
}

int test_copy_dir(const char *from, const char *to)
{
  printf("Testing copy_dir().\n");
  copy_dir(from, to);
  printf("Done!\n\n");
  return 0;
}

int test_copy_file(const char *from, const char *to)
{
  printf("Testing copy_file().\n");
  copy_file(from, to);
  printf("Done!\n\n");

  return 0;
}

void run_test ()
{
  /* Setting up the test. */
  FILE *fp;
  char from[] = "/tmp/banana.txt";
  fp = fopen(from, "w");
  fprintf(fp, "Testing the banana...\n");
  /* Finished setting up the test. */

  fclose(fp);
  test_copy_dir("/tmp/banana", "/tmp/banana2");
  test_copy_file("/tmp/banana.txt","/tmp/banana2.txt");
  test_copy("/tmp/banana.txt", "/tmp/banana2/");

}
