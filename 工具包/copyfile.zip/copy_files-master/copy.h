#ifdef COPY_H
#include "copy.h"
#else
#define COPY_H

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>

#define __WIN32__ 1

#if(defined(__WIN32__))
#include <io.h>  
#include <process.h>  
#define ssize_t unsigned int
#else
#include <unistd.h>
#endif

#include <stdio.h>
static struct stat sb;

#define TRUE !0
#define FALSE !TRUE

#define STAT_MODE_P(flag,clause) do\
{\
  if ((sb.st_mode & S_IFMT) & (flag))\
  (clause);\
  return;\
} while (0)

#define IS_FILE_P(clause) STAT_MODE_P(S_IFREG, clause)

#define IS_DIR_P(clause) STAT_MODE_P(S_IFDIR, clause)

#define CHECK_STAT(what, then) do\
{\
  if(stat((what), &sb) == -1)\
  then;\
} while (0)

/* The copy function checks wether 'from' is a file or a directory, the
 * real job is done by the two auxillary functions copy_dir and copy_file. */
void copy (const char *from, const char *to);

void copy_aux();

/* Auxillary function for finding all items recursivly in directory to copy. */
int copy_dir (const char *from, const char *to);

/* Auxillary function for copying the files into the right place. */
int copy_file (const char *from, const char *to);

#endif
