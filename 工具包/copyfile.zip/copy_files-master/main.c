#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "copy.h"

int main(void)
{
  run_test();
  return 0;
}
